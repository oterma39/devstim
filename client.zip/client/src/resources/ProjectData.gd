# res://src/resources/projects/ProjectData.gd
extends BaseItem
class_name ProjectData

@export var reward_funds: float
@export var required_lines: int

func can_afford() -> bool:
	return GameState.uncommitted_lines >= required_lines

func consume_cost():
	# 1. 코드 줄을 소모하여 작업을 처리
	print("create app")
	GameState.uncommitted_lines -= required_lines

func apply_effect():
	if can_afford():
		consume_cost()
		
		# 2. 자금 증가 및 갱신 (제대로 더해지도록 처리)
		GameState.funds += reward_funds
		print("자금 증가 확인: +", reward_funds, " / 현재 자금: ", GameState.funds)
		
		# UI에 자금 갱신 신호 보내기
		GameState.funds_changed.emit(GameState.funds)
		return true
	return false
